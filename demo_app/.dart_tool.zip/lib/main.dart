import 'package:demo_app/pages/splash_screen.dart';
import 'package:demo_app/theme/theme.dart';
import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(DevicePreview(builder:(context) =>const MyApp()));
  
   
}

class MyApp extends StatefulWidget{
  const MyApp ({super.key});

  @override
  MyAppState createState() => MyAppState();

}

class MyAppState extends State<MyApp>{
  @override
  Widget build(BuildContext context){
    return   MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Uni-Schooling',
      theme: AppThemeController.lightMode,
      home:const SplashScreen(),
      
    );
  }
}