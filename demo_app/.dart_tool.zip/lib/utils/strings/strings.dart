class HeadLines{
  static String welcomeTxt = 'welcome to school';
}