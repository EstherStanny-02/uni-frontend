class Images {
  static String splashImage = 'assets/logo.png';
}